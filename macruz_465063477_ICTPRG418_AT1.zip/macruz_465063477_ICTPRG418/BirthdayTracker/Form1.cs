﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace BirthdayTracker
{ 
    public partial class BirthdayTracker : Form
    {
        //private data
        //list of friends
        private List<Friend> friendList;
        private List<string> friendNameList;
        //array of months
        private string[] MonthName = { "1 - Jan", "2 - Feb", "3 - Mar", "4 - Apr", "5 - May", "6 - Jun", "7 - Jul", "8 - Aug", "9 - Sep", "10 - Oct", "11 - Nov", "12 - Dec", "ALL"};
        static int month = 0;

        /// <summary>
        /// /// Method: BirthdayTracker
        /// Purpose: Initializes components
        /// Input: void
        /// Output: void
        /// </summary>
        public BirthdayTracker()
        {
            InitializeComponent();
            

            //read friends data from external file
            friendList = Methods.GetFriendData();
            friendNameList = Methods.GetNamesData();

            //display all friends
            if (friendList.Count > 0)
            {
                //sort list of friends alphabetically
                friendNameList.Sort();
                friendList.Sort();
                list_textBox.Text = Methods.DisplayAllFriends("ALL", friendList);
            }
            
        }

        /// <summary>
        /// Method: bDayInMonth_button_Click
        /// Purpose: Change month selected
        /// Input: void
        /// Output: void
        /// </summary>
        private void bDayInMonth_button_Click(object sender, EventArgs e)
        {
            //display diferent month everytime button is clicked
            bDayInMonth_textBox.Text = MonthName[month];
            month = (month + 1) % 13;
            string bDayInMonth = bDayInMonth_textBox.Text;

            list_textBox.Text = Methods.DisplayAllFriends(bDayInMonth, friendList);
        }

        /// <summary>
        /// Method: exit_button_Click
        /// Purpose: Close application and save data of external file
        /// Input: void
        /// Output: void
        /// </summary>
        private void exit_button_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to exit?";
            const string caption = "EXIT";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                //export data to external file
                Methods.ExportCsv(friendList, @"MyFriendData.csv");
                MessageBox.Show("Your list has been saved to MyFriendData.csv", "Saved to external file");
                Application.Exit();
            }
            else if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        /// <summary>
        /// Method: find_button_Click
        /// Purpose: Search objects by name of friendsList
        /// Input: void
        /// Output: void
        /// </summary>
        private void find_button_Click(object sender, EventArgs e)
        {
            //calls method from method class and returns values to display
            string[] details = Methods.findFriend(find_textBox.Text, friendList, friendNameList);
            if (details[0] != " ")
            {
                name_textBox.Text = details[0];
                likes_textBox.Text = details[1];
                dislikes_textBox.Text = details[2];
                bDay_textBox.Text = details[3];
                month_textBox.Text = details[4];

                bDayInMonth_textBox.Text = "ALL";
                string bDayInMonth = bDayInMonth_textBox.Text;
                list_textBox.Text = Methods.DisplayAllFriends(bDayInMonth, friendList);
                find_textBox.Text = "";
            }
        }

        /// <summary>
        /// Method: new_button_Click
        /// Purpose: Add new objects to friendsList
        /// Input: void
        /// Output: void
        /// </summary>
        private void new_button_Click(object sender, EventArgs e)
        {
            if (Methods.ValidateString(name_textBox.Text) && Methods.ValidateString(likes_textBox.Text) && Methods.ValidateString(dislikes_textBox.Text))
            {
                if (!String.IsNullOrEmpty(month_textBox.Text))
                {
                    if (Int32.Parse(month_textBox.Text) < 13 && Int32.Parse(month_textBox.Text) > 0)
                    {
                        if (!String.IsNullOrEmpty(bDay_textBox.Text))
                        {
                            if (Methods.IsValidDay(Int32.Parse(month_textBox.Text), Int32.Parse(bDay_textBox.Text)))
                            {
                                //calls method from method class and returns values to display
                                string[] details = Methods.newFriend(name_textBox.Text, likes_textBox.Text, dislikes_textBox.Text, Int32.Parse(bDay_textBox.Text), Int32.Parse(month_textBox.Text), friendList, friendNameList);
                                if (details[0] != " ")
                                {
                                    name_textBox.Text = details[0];
                                    likes_textBox.Text = details[1];
                                    dislikes_textBox.Text = details[2];
                                    bDay_textBox.Text = details[3];
                                    month_textBox.Text = details[4];


                                    bDayInMonth_textBox.Text = "ALL";
                                    string bDayInMonth = bDayInMonth_textBox.Text;
                                    list_textBox.Text = Methods.DisplayAllFriends(bDayInMonth, friendList);
                                }
                            }
                            else
                            {
                                MessageBox.Show("ERROR: \r\n Require Birth Date", "ERROR(S) FOUND! NO SYMBOLS");
                            }
                        }
                        else
                        {
                            MessageBox.Show("ERROR: \r\n Require Birth Date", "ERROR(S) FOUND! NO SYMBOLS");
                        }
                    }
                    else
                    {
                        MessageBox.Show("ERROR: \r\n Require Birth Month", "ERROR(S) FOUND! NO SYMBOLS");
                    }
                }
                else
                {
                    MessageBox.Show("ERROR: \r\n Require Birth Month", "ERROR(S) FOUND! NO SYMBOLS");
                }
            }
        }

        /// <summary>
        /// Method: update_button_CLick
        /// Purpose: gets values from text boxes and updates element of friendList
        /// Input: void
        /// Output: void
        /// </summary>
        private void update_button_Click(object sender, EventArgs e)
        {
            if (Methods.ValidateString(name_textBox.Text) && Methods.ValidateString(likes_textBox.Text) && Methods.ValidateString(dislikes_textBox.Text))
            {
                if (Int32.Parse(month_textBox.Text) < 13 && Int32.Parse(month_textBox.Text) > 0)
                {
                    if (Methods.IsValidDay(Int32.Parse(month_textBox.Text), Int32.Parse(bDay_textBox.Text)))
                    {
                        //calls method from method class and returns values to display
                        string[] details = Methods.updateFriend(name_textBox.Text, likes_textBox.Text, dislikes_textBox.Text, Int32.Parse(bDay_textBox.Text), Int32.Parse(month_textBox.Text), friendList, friendNameList);

                        if (details[0] != " ")
                        {
                            name_textBox.Text = details[0];
                            likes_textBox.Text = details[1];
                            dislikes_textBox.Text = details[2];
                            bDay_textBox.Text = details[3];
                            month_textBox.Text = details[4];


                            bDayInMonth_textBox.Text = "ALL";
                            string bDayInMonth = bDayInMonth_textBox.Text;
                            list_textBox.Text = Methods.DisplayAllFriends(bDayInMonth, friendList);
                        }
                    }
                    else
                    {
                        MessageBox.Show("ERROR: \r\n Require Birth Date", "ERROR(S) FOUND! NO SYMBOLS");
                    }
                }
                else
                {
                    MessageBox.Show("ERROR: \r\n Require Birth Month", "ERROR(S) FOUND! NO SYMBOLS");
                }
            }
        }

        /// <summary>
        /// Method: delete_button_Click
        /// Purpose: deletes element from friendList
        /// Input: void
        /// Output: void
        /// </summary>
        private void delete_button_Click(object sender, EventArgs e)
        {
            string bDayInMonth = bDayInMonth_textBox.Text;
            const string message = "Are you sure you want to delete this friend?";
            const string caption = "DELETE FRIEND";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                string name = name_textBox.Text;
                Methods.deleteFriend(name, friendList, friendNameList);
                bDayInMonth_textBox.Text = "ALL";
                list_textBox.Text = Methods.DisplayAllFriends(bDayInMonth, friendList);
                name_textBox.Text = "";
                likes_textBox.Text = "";
                dislikes_textBox.Text = "";
                bDay_textBox.Text = "";
                month_textBox.Text = "";

            }
            else if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        /// <summary>
        /// Method: forward_button_Click
        /// Purpose: shows details of next friend of list by alphabetical order
        /// Input: void
        /// Output: void
        /// </summary>
        private void forward_button_Click(object sender, EventArgs e)
        {
            string name = name_textBox.Text;

            int friend = friendList.FindIndex(a => a.Name == name);

            if (String.IsNullOrEmpty(name) || friend == (friendList.Count - 1))
            {
                //finds first friend of the list
                var firstFriend = friendList.First();
                name_textBox.Text = firstFriend.Name;
                likes_textBox.Text = firstFriend.Likes;
                dislikes_textBox.Text = firstFriend.Dislikes;
                bDay_textBox.Text = firstFriend.BirthDate.ToString();
                month_textBox.Text = firstFriend.BirthMonth.ToString();
            }
            else
            {
                //finds next friend of list
                var nextFriend = friendList[friend + 1];
                name_textBox.Text = nextFriend.Name;
                likes_textBox.Text = nextFriend.Likes;
                dislikes_textBox.Text = nextFriend.Dislikes;
                bDay_textBox.Text = nextFriend.BirthDate.ToString();
                month_textBox.Text = nextFriend.BirthMonth.ToString();
            }
            bDayInMonth_textBox.Text = "ALL";
            string bDayInMonth = bDayInMonth_textBox.Text;
            list_textBox.Text = Methods.DisplayAllFriends(bDayInMonth, friendList);
        }

        /// <summary>
        /// Method: back_button_Click
        /// Purpose: shows details of previous friend of the list
        /// Input: void
        /// Output: void
        /// </summary>
        private void back_button_Click(object sender, EventArgs e)
        {
            string name = name_textBox.Text;
            int friend = friendList.FindIndex(a => a.Name == name);

            if (String.IsNullOrEmpty(name) || friend == 0)
            {
                var lastFriend = friendList[friendList.Count - 1];
                name_textBox.Text = lastFriend.Name;
                likes_textBox.Text = lastFriend.Likes;
                dislikes_textBox.Text = lastFriend.Dislikes;
                bDay_textBox.Text = lastFriend.BirthDate.ToString();
                month_textBox.Text = lastFriend.BirthMonth.ToString();
            }
            else
            {
                var nextFriend = friendList[friend - 1];
                name_textBox.Text = nextFriend.Name;
                likes_textBox.Text = nextFriend.Likes;
                dislikes_textBox.Text = nextFriend.Dislikes;
                bDay_textBox.Text = nextFriend.BirthDate.ToString();
                month_textBox.Text = nextFriend.BirthMonth.ToString();
            }
            bDayInMonth_textBox.Text = "ALL";
            string bDayInMonth = bDayInMonth_textBox.Text;
            list_textBox.Text = Methods.DisplayAllFriends(bDayInMonth, friendList);
        }

        /// <summary>
        /// Method: allBack_button_Click
        /// Purpose: shows details of first friend of the list
        /// Input: void
        /// Output: void
        /// </summary>
        private void allBack_button_Click(object sender, EventArgs e)
        {
            var firstFriend = friendList.First();
            name_textBox.Text = firstFriend.Name;
            likes_textBox.Text = firstFriend.Likes;
            dislikes_textBox.Text = firstFriend.Dislikes;
            bDay_textBox.Text = firstFriend.BirthDate.ToString();
            month_textBox.Text = firstFriend.BirthMonth.ToString();

            bDayInMonth_textBox.Text = "ALL";
            string bDayInMonth = bDayInMonth_textBox.Text;
            list_textBox.Text = Methods.DisplayAllFriends(bDayInMonth, friendList);
        }

        /// <summary>
        /// Method: allForward_button_Click
        /// Purpose: shows details of last friend of list
        /// Input: void
        /// Output: void
        /// </summary>
        private void allForward_button_Click(object sender, EventArgs e)
        {
            var lastFriend = friendList[friendList.Count - 1];
            name_textBox.Text = lastFriend.Name;
            likes_textBox.Text = lastFriend.Likes;
            dislikes_textBox.Text = lastFriend.Dislikes;
            bDay_textBox.Text = lastFriend.BirthDate.ToString();
            month_textBox.Text = lastFriend.BirthMonth.ToString();

            bDayInMonth_textBox.Text = "ALL";
            string bDayInMonth = bDayInMonth_textBox.Text;
            list_textBox.Text = Methods.DisplayAllFriends(bDayInMonth, friendList);
        }
    }
}
