﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BirthdayTracker
{
    /// <summary>
    /// Class: Friend : IComparable
    /// Purpose: Class created to manage list and compare values
    /// Input: void
    /// Output: void
    /// </summary>
    public class Friend : IComparable<Friend>
    {
        // private data properties 
        private string name;
        private string likes;
        private string dislikes;
        private int birthDate;
        private int birthMonth;

        //public data properties

        /// <summary>
        /// Method: Name
        /// Purpose: gets and returns value
        /// Input: void
        /// Output: void
        /// </summary>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        /// <summary>
        /// Method: Likes
        /// Purpose: gets and returns value
        /// Input: void
        /// Output: void
        /// </summary>
        public string Likes
        {
            get { return likes; }
            set { likes = value; }
        }
        /// <summary>
        /// Method: Dislikes
        /// Purpose: gets and returns value
        /// Input: void
        /// Output: void
        /// </summary>
        /// 
        public string Dislikes
        {
            get { return dislikes; }
            set { dislikes = value; }
        }

        /// <summary>
        /// Method: BirthDate
        /// Purpose: gets and returns value
        /// Input: void
        /// Output: void
        /// </summary>
        public int BirthDate
        {
            get { return birthDate; }
            set { birthDate = value; }
        }

        /// <summary>
        /// Method: BirthMonth
        /// Purpose: gets and returns value
        /// Input: void
        /// Output: void
        /// </summary>
        public int BirthMonth
        {
            get { return birthMonth; }
            set { birthMonth = value; }
        }

        //contructor method
        /// <summary>
        /// Method: Friend
        /// Purpose: gets values
        /// Input: void
        /// Output: void
        /// </summary>
        public Friend(string name, string likes, string dislikes, int birthDate, int birthMonth)
        {
            Name = name;
            Likes = likes;
            Dislikes = dislikes;
            BirthDate = birthDate;
            BirthMonth = birthMonth;
        }

        /// <summary>
        /// Method: CompareTo
        /// Purpose: compare values
        /// Input: void
        /// Output: void
        /// </summary>
        public int CompareTo(Friend other)
        {
            //return 0 if names are identical
            //returns -1 if Name < other.Name
            // return 1 if Name > other.Name
            return Name.CompareTo(other.Name);
        }

        /// <summary>
        /// Method: ToString
        /// Purpose: converts values to string
        /// Input: void
        /// Output: void
        /// </summary>
        public override string ToString()
        {
            return Name + "\t\t" + Likes + "\t\t" + Dislikes + "\t\t" + BirthDate + "\t" + BirthMonth;
        }
    }
}
