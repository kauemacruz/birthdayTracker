﻿namespace BirthdayTracker
{
    partial class BirthdayTracker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bDayInMonth_textBox = new System.Windows.Forms.TextBox();
            this.bDayInMonth_button = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.name_textBox = new System.Windows.Forms.TextBox();
            this.likes_textBox = new System.Windows.Forms.TextBox();
            this.dislikes_textBox = new System.Windows.Forms.TextBox();
            this.bDay_textBox = new System.Windows.Forms.TextBox();
            this.month_textBox = new System.Windows.Forms.TextBox();
            this.find_textBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.find_button = new System.Windows.Forms.Button();
            this.new_button = new System.Windows.Forms.Button();
            this.update_button = new System.Windows.Forms.Button();
            this.delete_button = new System.Windows.Forms.Button();
            this.exit_button = new System.Windows.Forms.Button();
            this.allBack_button = new System.Windows.Forms.Button();
            this.back_button = new System.Windows.Forms.Button();
            this.forward_button = new System.Windows.Forms.Button();
            this.allForward_button = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.list_textBox = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(162, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Birthday Tracker";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(16, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Person\'s Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(16, 106);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 18);
            this.label3.TabIndex = 2;
            this.label3.Text = "Likes:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(16, 148);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 18);
            this.label4.TabIndex = 3;
            this.label4.Text = "Dislikes:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(16, 190);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 18);
            this.label5.TabIndex = 4;
            this.label5.Text = "B/day day:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.bDayInMonth_textBox);
            this.groupBox1.Controls.Add(this.bDayInMonth_button);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Location = new System.Drawing.Point(522, 360);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(232, 120);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            // 
            // bDayInMonth_textBox
            // 
            this.bDayInMonth_textBox.Enabled = false;
            this.bDayInMonth_textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bDayInMonth_textBox.Location = new System.Drawing.Point(16, 81);
            this.bDayInMonth_textBox.Name = "bDayInMonth_textBox";
            this.bDayInMonth_textBox.Size = new System.Drawing.Size(200, 24);
            this.bDayInMonth_textBox.TabIndex = 18;
            this.bDayInMonth_textBox.Text = "ALL";
            this.bDayInMonth_textBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bDayInMonth_button
            // 
            this.bDayInMonth_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bDayInMonth_button.Location = new System.Drawing.Point(16, 37);
            this.bDayInMonth_button.Name = "bDayInMonth_button";
            this.bDayInMonth_button.Size = new System.Drawing.Size(200, 38);
            this.bDayInMonth_button.TabIndex = 18;
            this.bDayInMonth_button.Text = "Birthdays in month of:";
            this.bDayInMonth_button.UseVisualStyleBackColor = true;
            this.bDayInMonth_button.Click += new System.EventHandler(this.bDayInMonth_button_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(90, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 18);
            this.label8.TabIndex = 0;
            this.label8.Text = "Search";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(16, 234);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 18);
            this.label6.TabIndex = 6;
            this.label6.Text = "B/day Month:";
            // 
            // name_textBox
            // 
            this.name_textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name_textBox.Location = new System.Drawing.Point(180, 66);
            this.name_textBox.Name = "name_textBox";
            this.name_textBox.Size = new System.Drawing.Size(232, 24);
            this.name_textBox.TabIndex = 7;
            // 
            // likes_textBox
            // 
            this.likes_textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.likes_textBox.Location = new System.Drawing.Point(180, 106);
            this.likes_textBox.Name = "likes_textBox";
            this.likes_textBox.Size = new System.Drawing.Size(232, 24);
            this.likes_textBox.TabIndex = 8;
            // 
            // dislikes_textBox
            // 
            this.dislikes_textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dislikes_textBox.Location = new System.Drawing.Point(180, 148);
            this.dislikes_textBox.Name = "dislikes_textBox";
            this.dislikes_textBox.Size = new System.Drawing.Size(232, 24);
            this.dislikes_textBox.TabIndex = 9;
            // 
            // bDay_textBox
            // 
            this.bDay_textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bDay_textBox.Location = new System.Drawing.Point(180, 190);
            this.bDay_textBox.Name = "bDay_textBox";
            this.bDay_textBox.Size = new System.Drawing.Size(232, 24);
            this.bDay_textBox.TabIndex = 10;
            // 
            // month_textBox
            // 
            this.month_textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.month_textBox.Location = new System.Drawing.Point(180, 234);
            this.month_textBox.Name = "month_textBox";
            this.month_textBox.Size = new System.Drawing.Size(232, 24);
            this.month_textBox.TabIndex = 11;
            // 
            // find_textBox
            // 
            this.find_textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.find_textBox.Location = new System.Drawing.Point(565, 60);
            this.find_textBox.Name = "find_textBox";
            this.find_textBox.Size = new System.Drawing.Size(189, 24);
            this.find_textBox.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(519, 63);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 18);
            this.label7.TabIndex = 13;
            this.label7.Text = "Find:";
            // 
            // find_button
            // 
            this.find_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.find_button.Location = new System.Drawing.Point(522, 90);
            this.find_button.Name = "find_button";
            this.find_button.Size = new System.Drawing.Size(232, 29);
            this.find_button.TabIndex = 14;
            this.find_button.Text = "Find";
            this.find_button.UseVisualStyleBackColor = true;
            this.find_button.Click += new System.EventHandler(this.find_button_Click);
            // 
            // new_button
            // 
            this.new_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.new_button.Location = new System.Drawing.Point(522, 148);
            this.new_button.Name = "new_button";
            this.new_button.Size = new System.Drawing.Size(232, 33);
            this.new_button.TabIndex = 15;
            this.new_button.Text = "New";
            this.new_button.UseVisualStyleBackColor = true;
            this.new_button.Click += new System.EventHandler(this.new_button_Click);
            // 
            // update_button
            // 
            this.update_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.update_button.Location = new System.Drawing.Point(522, 187);
            this.update_button.Name = "update_button";
            this.update_button.Size = new System.Drawing.Size(232, 32);
            this.update_button.TabIndex = 16;
            this.update_button.Text = "Update";
            this.update_button.UseVisualStyleBackColor = true;
            this.update_button.Click += new System.EventHandler(this.update_button_Click);
            // 
            // delete_button
            // 
            this.delete_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delete_button.Location = new System.Drawing.Point(522, 225);
            this.delete_button.Name = "delete_button";
            this.delete_button.Size = new System.Drawing.Size(232, 30);
            this.delete_button.TabIndex = 17;
            this.delete_button.Text = "Delete";
            this.delete_button.UseVisualStyleBackColor = true;
            this.delete_button.Click += new System.EventHandler(this.delete_button_Click);
            // 
            // exit_button
            // 
            this.exit_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit_button.Location = new System.Drawing.Point(522, 527);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(232, 29);
            this.exit_button.TabIndex = 18;
            this.exit_button.Text = "Exit";
            this.exit_button.UseVisualStyleBackColor = true;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            // 
            // allBack_button
            // 
            this.allBack_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.allBack_button.Location = new System.Drawing.Point(16, 289);
            this.allBack_button.Name = "allBack_button";
            this.allBack_button.Size = new System.Drawing.Size(47, 27);
            this.allBack_button.TabIndex = 19;
            this.allBack_button.Text = "|<";
            this.allBack_button.UseVisualStyleBackColor = true;
            this.allBack_button.Click += new System.EventHandler(this.allBack_button_Click);
            // 
            // back_button
            // 
            this.back_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back_button.Location = new System.Drawing.Point(69, 289);
            this.back_button.Name = "back_button";
            this.back_button.Size = new System.Drawing.Size(47, 27);
            this.back_button.TabIndex = 20;
            this.back_button.Text = "<";
            this.back_button.UseVisualStyleBackColor = true;
            this.back_button.Click += new System.EventHandler(this.back_button_Click);
            // 
            // forward_button
            // 
            this.forward_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.forward_button.Location = new System.Drawing.Point(127, 289);
            this.forward_button.Name = "forward_button";
            this.forward_button.Size = new System.Drawing.Size(47, 27);
            this.forward_button.TabIndex = 21;
            this.forward_button.Text = ">";
            this.forward_button.UseVisualStyleBackColor = true;
            this.forward_button.Click += new System.EventHandler(this.forward_button_Click);
            // 
            // allForward_button
            // 
            this.allForward_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.allForward_button.Location = new System.Drawing.Point(180, 289);
            this.allForward_button.Name = "allForward_button";
            this.allForward_button.Size = new System.Drawing.Size(47, 27);
            this.allForward_button.TabIndex = 22;
            this.allForward_button.Text = ">|";
            this.allForward_button.UseVisualStyleBackColor = true;
            this.allForward_button.Click += new System.EventHandler(this.allForward_button_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(19, 330);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(92, 18);
            this.label9.TabIndex = 23;
            this.label9.Text = "Birthday List:";
            // 
            // list_textBox
            // 
            this.list_textBox.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar;
            this.list_textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.list_textBox.Location = new System.Drawing.Point(22, 363);
            this.list_textBox.Multiline = true;
            this.list_textBox.Name = "list_textBox";
            this.list_textBox.ReadOnly = true;
            this.list_textBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.list_textBox.Size = new System.Drawing.Size(484, 196);
            this.list_textBox.TabIndex = 24;
            // 
            // BirthdayTracker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(764, 581);
            this.Controls.Add(this.list_textBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.allForward_button);
            this.Controls.Add(this.forward_button);
            this.Controls.Add(this.back_button);
            this.Controls.Add(this.allBack_button);
            this.Controls.Add(this.exit_button);
            this.Controls.Add(this.delete_button);
            this.Controls.Add(this.update_button);
            this.Controls.Add(this.new_button);
            this.Controls.Add(this.find_button);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.find_textBox);
            this.Controls.Add(this.month_textBox);
            this.Controls.Add(this.bDay_textBox);
            this.Controls.Add(this.dislikes_textBox);
            this.Controls.Add(this.likes_textBox);
            this.Controls.Add(this.name_textBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "BirthdayTracker";
            this.Text = "BIRTHDAY TRACKER";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox name_textBox;
        private System.Windows.Forms.TextBox likes_textBox;
        private System.Windows.Forms.TextBox dislikes_textBox;
        private System.Windows.Forms.TextBox bDay_textBox;
        private System.Windows.Forms.TextBox month_textBox;
        private System.Windows.Forms.TextBox find_textBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button find_button;
        private System.Windows.Forms.Button new_button;
        private System.Windows.Forms.Button update_button;
        private System.Windows.Forms.Button delete_button;
        private System.Windows.Forms.TextBox bDayInMonth_textBox;
        private System.Windows.Forms.Button bDayInMonth_button;
        private System.Windows.Forms.Button exit_button;
        private System.Windows.Forms.Button allBack_button;
        private System.Windows.Forms.Button back_button;
        private System.Windows.Forms.Button forward_button;
        private System.Windows.Forms.Button allForward_button;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox list_textBox;
    }
}

