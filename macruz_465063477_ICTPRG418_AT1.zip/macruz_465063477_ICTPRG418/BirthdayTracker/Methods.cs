﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace BirthdayTracker
{
    /// <summary>
    /// 
    /// </summary>
    public static class Methods
    {
        /// <summary>
        /// Method: GetFriendData
        /// Purpose: read friend data from external file
        /// Input: void
        /// Output: void
        /// </summary>
        public static List<Friend> GetFriendData()
        {

            List<Friend> friendList = new List<Friend>();
            //external file source
            string filePath = @"MyFriendData.csv";
            //read external file
            try
            {
                if (File.Exists(filePath))
                {
                    using (StreamReader streamReader = new StreamReader(filePath))
                    {
                        string line = " ";

                        //start reading
                        while ((line = streamReader.ReadLine()) != null)
                        {
                            string[] lineArray = line.Split(',');
                            string name = lineArray[0];
                            string likes = lineArray[1];
                            string dislikes = lineArray[2];
                            int birthDate = Int32.Parse(lineArray[3]);
                            int birthMonth = Int32.Parse(lineArray[4]);

                            Friend friend = new Friend(name, likes, dislikes, birthDate, birthMonth);
                            friendList.Add(friend);
                        }

                        streamReader.Close();
                    }


                }
                else
                {
                    Console.WriteLine("Error: file does not exist");
                }
            }
            catch (IOException ioe)
            {
                //catch specific IO exception
                Console.WriteLine("Error: Problem in reading external file: " + filePath);
                Console.WriteLine(ioe.Message);
                //Console.WriteLine(ioe.StackTrace);
            }
            catch (Exception)
            {
                //catch all exceptions
                Console.WriteLine("Error: Problem in IO for: " + filePath);
            }
            return friendList;
        }

        /// <summary>
        /// Method: GetNamesData
        /// Purpose: read names data from external file
        /// Input: void
        /// Output: void
        /// </summary>
        public static List<string> GetNamesData()
        {
            List<string> friendNameList = new List<string>();
            //external file source
            string filePath = @"MyFriendData.csv";
            //read external file
            try
            {
                if (File.Exists(filePath))
                {
                    using (StreamReader streamReader = new StreamReader(filePath))
                    {
                        string line = " ";

                        //start reading
                        while ((line = streamReader.ReadLine()) != null)
                        {
                            string[] lineArray = line.Split(',');
                            string name = lineArray[0];

                            friendNameList.Add(name);
                        }

                        streamReader.Close();
                    }


                }
                else
                {
                    Console.WriteLine("Error: file does not exist");
                }
            }
            catch (IOException ioe)
            {
                //catch specific IO exception
                Console.WriteLine("Error: Problem in reading external file: " + filePath);
                Console.WriteLine(ioe.Message);
                //Console.WriteLine(ioe.StackTrace);
            }
            catch (Exception)
            {
                //catch all exceptions
                Console.WriteLine("Error: Problem in IO for: " + filePath);
            }
            return friendNameList;
        }

        /// <summary>
        /// Method: DisplayAllFriends
        /// Purpose: set friends data from external file to list
        /// Input: void
        /// Output: void
        /// </summary>
        /// 
        public static string DisplayAllFriends(string bDayInMonth, List<Friend> friendList)
        {
            string displayText = "Person\t\tLikes\t\tDislikes\t\tDay\tMonth ------------------------------------------------------------------------------------------------------------------ \r\n";

            //list_textBox display all objects
            if (bDayInMonth == "ALL")
            {
                for (int i = 0; i < friendList.Count; i++)
                {
                    displayText += friendList[i].ToString() + "\r\n";
                }
            }
            else
            {
                //display specific month selected
                string[] monthInt = bDayInMonth.Split(' ');
                int monthToDisplay = Int32.Parse(monthInt[0]);

                var displayFriendsOfMonth = friendList.Where(a => a.BirthMonth == monthToDisplay);

                foreach (var person in displayFriendsOfMonth)
                {
                    displayText += person.Name + "\t\t" + person.Likes + "\t\t" + person.Dislikes + "\t\t" + person.BirthDate + "\t" + person.BirthMonth + "\r\n";
                }
            }
            return displayText;
        }

        /// <summary>
        /// Method: ValidateString
        /// Purpose: Check if string has no symbols
        /// Input: void
        /// Output: void
        /// </summary>
        public static bool ValidateString(string value)
        {

            if (!Regex.Match(value, "^[A-Z][a-zA-Z\\s]*$").Success || String.IsNullOrEmpty(value))
            {
                // string was not entered properly 
                MessageBox.Show("ERROR: \r\n Require Name \r\n Require Likes \r\n Require Dislikes", "ERROR(S) FOUND! NO SYMBOLS ");
                return false;
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// Method: isValidDay
        /// Purpose: checks if date exists
        /// Input: void
        /// Output: void
        /// </summary>
        public static bool IsValidDay(int month, int day)
        {
            int total_days_in_month;

            switch (month)
            {
                //months with 31 days
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                case 12:
                    total_days_in_month = 31;
                    break;
                //months with 30 days
                case 4:
                case 6:
                case 9:
                case 11:
                    total_days_in_month = 30;
                    break;
                //february
                case 2:
                default:
                    total_days_in_month = 28;
                    break;
            }
            //day entered must be less or equal than days of month
            return (day <= total_days_in_month);
        }

        /// <summary>
        /// Method: ExportCsv
        /// Purpose: exports list to external file
        /// Input: void
        /// Output: void
        /// </summary>
        public static void ExportCsv<T>(IEnumerable<T> items, string path)
        {
            Type itemType = typeof(T);
            var props = itemType.GetProperties(BindingFlags.Public | BindingFlags.Instance);

            using (var writer = new StreamWriter(path))
            {

                foreach (var item in items)
                {
                    writer.WriteLine(string.Join(",", props.Select(p => p.GetValue(item, null))));
                }
            }
        }

        /// <summary>
        /// Method: findFriend
        /// Purpose: search friend by name
        /// Input: void
        /// Output: void
        /// </summary>
        public static string[] findFriend(string find, List<Friend> friendList, List<string> friendNameList)
        {
            string name;
            string likes;
            string dislikes;
            string bday;
            string month;

            if (String.IsNullOrEmpty(find))
            {
                MessageBox.Show("Enter a name", "Empty Search");
            }
            else
            {

                int foundIndex = friendNameList.BinarySearch(find);
                if (foundIndex >= 0)
                { 
                    //find element by name
                    var searchFriend = friendList.Where(a => a.Name == find);

                    if (searchFriend.Count() > 0)
                    {
                        foreach (var person in searchFriend)
                        {
                            name = person.Name;
                            likes = person.Likes;
                            dislikes = person.Dislikes;
                            bday = person.BirthDate.ToString();
                            month = person.BirthMonth.ToString();
                            string[] details = {name, likes, dislikes, bday, month};
                            return details;
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Sorry, no name for " + find, "Not Found");
                }
            }
            string[] empty = {" "};
            return empty;
        }

        /// <summary>
        /// Method: addFriend
        /// Purpose: add friend to list
        /// Input: void
        /// Output: void
        /// </summary>
        public static string[] newFriend(string name, string likes, string dislikes, int birthDate, int birthMonth, List<Friend> friendList, List<string> friendNameList)
        {
            var addFriend = friendList.Where(a => a.Name == name);

            if (addFriend.Count() > 0)
            {
                MessageBox.Show("Sorry, " + name + " alredy exists", "Duplicated Name");
            }
            else
            {
                if (Methods.ValidateString(name) && Methods.ValidateString(likes) && Methods.ValidateString(dislikes))
                {
                    if (birthMonth < 13 && birthMonth > 0)
                    {
                        if (!String.IsNullOrEmpty(birthDate.ToString()) && Methods.IsValidDay(birthMonth, birthDate))
                        {
                            Friend friend = new Friend(name, likes, dislikes, birthDate, birthMonth);
                            friendList.Add(friend);
                            friendList.Sort();

                            friendNameList.Add(name);
                            friendNameList.Sort();


                            string[] details = { name, likes, dislikes, birthDate.ToString(), birthMonth.ToString() };
                            return details;
                        }
                        else
                        {
                            MessageBox.Show("ERROR: \r\n Require Birth Date", "ERROR(S) FOUND! NO SYMBOLS");
                        }
                    }
                    else
                    {
                        MessageBox.Show("ERROR: \r\n Require Birth Month", "ERROR(S) FOUND! NO SYMBOLS");
                    }
                }
            }
            string[] empty = { " " };
            return empty;
        }

        /// <summary>
        /// Method: addFriend
        /// Purpose: add friend to list
        /// Input: void
        /// Output: void
        /// </summary>
        public static string[] updateFriend(string name, string likes, string dislikes, int birthDate, int birthMonth, List<Friend> friendList, List<string> friendNameList)
        {
            var friend = friendList.FirstOrDefault(x => x.Name == name);
            int index = friendNameList.FindIndex(n => n == name);
            

            if (ValidateString(name) && ValidateString(likes) && ValidateString(dislikes))
            {
                if (birthMonth < 13 && birthMonth > 0)
                {
                    if (IsValidDay(birthMonth, birthDate))
                    {
                        if (friend != null)
                        {
                            friend.Name = name;
                            friend.Likes = likes;
                            friend.Dislikes = dislikes;
                            friend.BirthDate = birthDate;
                            friend.BirthMonth = birthMonth;

                            friendList.Sort();

                            friendNameList[index] = name;
                            friendNameList.Sort();

                            string[] details = { name, likes, dislikes, birthDate.ToString(), birthMonth.ToString() };
                            return details;
                        }
                        else
                        {
                            MessageBox.Show("ERROR: \r\n No friend with that name", "ERROR");

                        }
                    }
                    else
                    {
                        MessageBox.Show("ERROR: \r\n Require Birth Date", "ERROR(S) FOUND! NO SYMBOLS");
                    }
                }
                else
                {
                    MessageBox.Show("ERROR: \r\n Require Birth Month", "ERROR(S) FOUND! NO SYMBOLS");
                }
            }
            string[] empty = { " " };
            return empty;
        }

        /// <summary>
        /// Method: deleteFriend
        /// Purpose: delete friend from list
        /// Input: void
        /// Output: void
        /// </summary>
        public static void deleteFriend(string name, List<Friend> friendList, List<string> friendNameList) 
        {
            var deleteFriend = friendList.SingleOrDefault(a => a.Name == name);
            int index = friendNameList.FindIndex(n => n == name);

            if (deleteFriend != null)
            {
                friendList.Remove(deleteFriend);
                friendNameList.RemoveAt(index);
            }
            else
            {
                MessageBox.Show("ERROR: \r\n No friend with that name", "ERROR");
            }
        }
    }
}
