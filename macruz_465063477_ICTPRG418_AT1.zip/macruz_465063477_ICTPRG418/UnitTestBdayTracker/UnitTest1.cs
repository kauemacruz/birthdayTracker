﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using BirthdayTracker;

namespace UnitTestBdayTracker
{
    [TestClass]
    public class UnitTest1
    {

        /// <summary>
        /// Method: AreSame
        /// Purpose: check if both number are equal
        /// Input: void
        /// Output: void
        /// </summary>
        public bool AreSame(int list1, int list2)
        {
            bool result = true;

            if (list1 == list2)
            {
                result = true;

            }
            else
            {
                result = false;
            }
            return result;
        }

        /// <summary>
        /// Method: indexFound
        /// Purpose: if index is bigger than or equal to zero it means that index exists 
        /// Input: void
        /// Output: void
        /// </summary>
        public bool IndexFound(int index)
        {
            bool result = true;

            if (index >= 0)
            {
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }

        /// <summary>
        /// Method: TestMethod1
        /// Purpose: add new user to list imported from external file and checks if an extra element was added to list
        /// Input: void
        /// Output: void
        /// </summary>
        [TestMethod]
        public void TestMethod1()
        {
            List<BirthdayTracker.Friend> friendList = BirthdayTracker.Methods.GetFriendData();
            List<string> friendNames = BirthdayTracker.Methods.GetNamesData();

            int listBeforeNew = friendList.Count + 1;

            BirthdayTracker.Methods.newFriend("Kaue", "Development", "Documentation", 18, 4, friendList, friendNames);
            int listAfterNew = friendList.Count;

            bool expectedResult = true;
            bool actualResult = AreSame(listBeforeNew, listAfterNew);
            Assert.AreEqual(expectedResult, actualResult);

        }

        /// <summary>
        /// Method: TestMethod2
        /// Purpose: adds new element to imported list from external file and checks if element was actually added to list
        /// Input: void
        /// Output: void
        /// </summary>

        [TestMethod]
        public void TestMethod2()
        {
            List<BirthdayTracker.Friend> friendList = BirthdayTracker.Methods.GetFriendData();
            List<string> friendNames = BirthdayTracker.Methods.GetNamesData();

            BirthdayTracker.Methods.newFriend("Kaue", "Development", "Documentation", 18, 4, friendList, friendNames);

            int foundIndex = friendNames.BinarySearch("Kaue");

            bool expectedResult = true;
            bool actualResult = IndexFound(foundIndex);
            Assert.AreEqual(expectedResult, actualResult);
        }
    }
}
